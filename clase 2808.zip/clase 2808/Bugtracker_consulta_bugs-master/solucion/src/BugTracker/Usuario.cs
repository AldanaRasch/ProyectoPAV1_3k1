﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPS_InicioSesion
{
    public class Usuario
    {
        public string usuario { get; set; }
        public string password { get; set; }

    }
}
