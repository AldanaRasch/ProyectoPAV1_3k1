﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugTracker.Models
{
    class Categoria
    {
        int idCategoria { get; set; }
        string nombre { get; set; }
    }
}
